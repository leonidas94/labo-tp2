Expliaci�n de los archivos contenidos en la carpeta:

TP2_Bergler_Neumarkt.pdf: Informe del trabajo pr�ctico. 

tp2_final: C�digo en Arduino para realizar el trabajo pr�ctico.

test_speed: C�digo en Arduino para hacer girar el motor a m�xima velocidad y calcular su velocidad. 

Comunicacion_serie_.slx: Archivo de Simulink para comunicar la PC con el Arduino. 
			 De esta manera se envi�n las constantes del PID y la referencia y se observa la velocidad del motor y el ciclo de trabajo.

com_serie_speed.slx: Archivo en Simulink para observar la velocidad del motor utilizando el archivo "test_speed.ino".

identificacion_motor.m: Archivo de Matlab para realizar la identificaci�n del motor.

simulacion_lazo_cerrado.slx: Archivo de Simulink para realizar la simulaci�n a lazo cerrado, utilizando la transferencia obtenida de la identificaci�n del motor. 

TimerOne-master.zip: Librer�a para incluir en Arduino IDE. 

